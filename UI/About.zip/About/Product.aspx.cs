﻿using System;
using System.Web.UI;


namespace GoTournamental.UI {

	public partial class Product : Page {

		//AdvertPanel advert120x600 = new AdvertPanel();

		protected void Page_Load(object sender, EventArgs e) {

			//advert120x600 = (AdvertPanel)AboutPanel.FindControl("Advert120x600");
			//advert120x600.graphicFileStyle = Advert.GraphicFileStyles.Advert120By600;
			//advert120x600.tournamentID = 0;

		}

	}

}